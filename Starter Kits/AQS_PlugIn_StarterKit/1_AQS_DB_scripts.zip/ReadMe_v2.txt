AQS scripts create AQS exchange tables and include stored procedures 
for exporting from Exchange Tables to AQS XML foramt.

Run in this order: 
-------------------------------------
1_AQ_tables_create.sql
2_SP_AQS.sql
3_SP_AQS_XML_GEN.sql
4_SP_AQS_XML_GEN_DEL.sql
5_patch_20090924_AQ_tables_alter.sql
6_patch_20091124_AQ_tables_alter.sql