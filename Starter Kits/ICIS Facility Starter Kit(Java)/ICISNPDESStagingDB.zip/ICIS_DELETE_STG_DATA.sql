create or replace PROCEDURE ICIS_DELETE_STG_DATA
( p_TRANS_ID IN VARCHAR2
, p_SUCCESS_IND OUT VARCHAR2)
AS
--**************************************************************************************************
--* Object Name:        -- ICIS_DELETE_STG_DATA
--* Product Name:       -- EN-Node
--* Platform:           -- Oracle 10g
--* Client(s):          -- NJDEP
--**************************************************************************************************
--* Description:        -- To delete ICIS temporary staging data for the specific Transaction ID
--**************************************************************************************************
--* Created by:         -- 20120120 enfoTech Consulting, Inc./Nicki Chang 
--**************************************************************************************************

BEGIN

p_SUCCESS_IND:='ERROR';
--DBMS_OUTPUT.PUT_LINE(TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI:SS'));

-- ***********************************************
-- PARAMETER VALIDATION
-- ***********************************************
IF p_TRANS_ID IS NULL THEN
  RAISE_APPLICATION_ERROR(-20999, 'p_TRANS_ID MUST NOT BE NUL.');
  RETURN;
END IF;

BEGIN
    DELETE FROM ICIS_TEMP_XML WHERE TRANSACTION_ID=p_TRANS_ID;
EXCEPTION
    WHEN OTHERS THEN 
    RAISE_APPLICATION_ERROR(-20999, 'ERROR DURING DELETING STAGING DATA.');
    RETURN;
END;
COMMIT;

--DBMS_OUTPUT.PUT_LINE(TO_CHAR(SYSDATE,'YYYYMMDD HH24:MI:SS'));
p_SUCCESS_IND:='OK';
END;
/