create or replace
PROCEDURE         USP_GENERATE_TRANSACT_SVC_XML
( p_TRANS_ID VARCHAR2
, p_DATAFLOW VARCHAR2
, p_STATUS VARCHAR2
, p_TYPE VARCHAR2
, p_USERID VARCHAR2
, p_RECIPIENTS VARCHAR2
, p_ORGANIZATION VARCHAR2
, p_TO_DATE VARCHAR2
, p_FROM_DATE VARCHAR2
, p_RESULT OUT VARCHAR2
)
AS

--**************************************************************************************************
--* Object Name:        -- USP_GENERATE_TRANSACT_SVC_XML
--* Product Name:       -- EN-Node
--* Platform:           -- Oracle 10g
--* Client(s):          -- All
--**************************************************************************************************
--* Description:        -- To generate XML file containing transaction details
--* Input Parameters:   
--**************************************************************************************************
--* Created by:         -- enfoTech Consulting, Inc./Doug Timms
--* Modified            -- 12/9/2010
--**************************************************************************************************

v_CLOB CLOB;
v_CLOBtemp CLOB;
v_XML XMLTYPE;
p_to_date2 varchar2(20);
p_from_date2 varchar2(20);

BEGIN 

if length(p_TO_DATE)<2 then 
   p_to_date2 := '12/31/2050';
else
   p_to_date2 := p_to_date;
END IF;
if length(p_FROM_DATE)<2 then 
   p_from_date2 := '1/1/2000';
else
   p_from_date2 := p_from_date;
END IF;

v_XML:=null;

v_CLOB:='<?xml version="1.0" encoding="UTF-8"?>
<TransactionList xmlns="http://www.exchangenetwork.net/schema/tts/1" 
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">';

if length(p_STATUS)<2 then
   select XMLAgg(
        XMLElement("Transaction", XMLForest(
              TRANS_ID as "TransactionId",
              op.OPERATION_NAME as "DataflowName",
              ws.WEB_SERVICE_NAME as "TransactionType",
              (select STATUS_CD from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "TransactionStatus",
              (select substr(MESSAGE,1,100) from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "StatusDescription",
              to_char(LOG.CREATED_DTTM,'YYYY-MM-DD') as "CreationDateTime",
              USER_NAME as "UserId")
         )
    )
    INTO v_XML
    from NODE_OPERATION_LOG LOG , NODE_OPERATION op, NODE_WEB_SERVICE ws
    where op.OPERATION_ID = LOG.OPERATION_ID
    and op.WEB_SERVICE_ID = ws.WEB_SERVICE_ID
    and LOG.TRANS_ID LIKE CASE when length(p_TRANS_ID)<2 then '%%' else p_TRANS_ID end
    and op.OPERATION_NAME LIKE CASE when length(p_dataflow)<2 then '%%' else p_dataflow end
    and LOG.USER_NAME LIKE CASE when length(p_USERID)<2 then '%%' else p_USERID end
    and ws.WEB_SERVICE_NAME LIKE CASE when length(p_TYPE)<2 then '%%' else p_TYPE end
    and LOG.CREATED_DTTM >= to_date(p_from_date2,'MM/DD/YYYY')
    and LOG.CREATED_DTTM <= to_date(p_to_date2,'MM/DD/YYYY')
    and rownum<=10
    order by LOG.CREATED_DTTM desc;
else
   select XMLAgg(
        XMLElement("Transaction", XMLForest(
              TRANS_ID as "TransactionId",
              op.OPERATION_NAME as "DataflowName",
              ws.WEB_SERVICE_NAME as "TransactionType",
              (select STATUS_CD from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "TransactionStatus",
              (select substr(MESSAGE,1,100) from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "StatusDescription",
              to_char(LOG.CREATED_DTTM,'YYYY-MM-DD') as "CreationDateTime",
              USER_NAME as "UserId")
         )
    )
    INTO v_XML
    from NODE_OPERATION_LOG LOG , NODE_OPERATION op, NODE_WEB_SERVICE ws
    where op.OPERATION_ID = LOG.OPERATION_ID
    and op.WEB_SERVICE_ID = ws.WEB_SERVICE_ID
    and LOG.TRANS_ID LIKE CASE when length(p_TRANS_ID)<2 then '%%' else p_TRANS_ID end
    and op.OPERATION_NAME LIKE CASE when length(p_dataflow)<2 then '%%' else p_dataflow end
    and LOG.USER_NAME LIKE CASE when length(p_USERID)<2 then '%%' else p_USERID end
    and ws.WEB_SERVICE_NAME LIKE CASE when length(p_TYPE)<2 then '%%' else p_TYPE end
    and OPERATION_LOG_ID in (select OPERATION_LOG_ID from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID and STATUS_CD = p_STATUS))
    and LOG.CREATED_DTTM >= to_date(p_from_date2,'MM/DD/YYYY')
    and LOG.CREATED_DTTM <= to_date(p_to_date2,'MM/DD/YYYY')
    and rownum<=10
    order by LOG.CREATED_DTTM desc;
end if;

if v_XML is not null then
   v_CLOBtemp := v_XML.getClobVal(); 
else 
   v_CLOBtemp := '';
end if;

p_RESULT:=v_CLOB || v_CLOBtemp || '</TransactionList>';

END USP_GENERATE_TRANSACT_SVC_XML;
/