create or replace
PROCEDURE         USP_GENERATE_TRANSACT_DTL_XML
( p_TRANS_ID VARCHAR2
, p_RESULT OUT VARCHAR2
)
AS

--**************************************************************************************************
--* Object Name:        -- USP_GENERATE_TRANSACT_DTL_XML
--* Product Name:       -- EN-Node
--* Platform:           -- Oracle 10g
--* Client(s):          -- All
--* Description:        -- To generate XML file containing transaction details
--* Created by:         -- enfoTech Consulting, Inc./Doug Timms
--* Modified            -- 12/9/2010
--**************************************************************************************************

v_CLOB CLOB;
v_CLOBtemp CLOB;
v_XML XMLTYPE;

BEGIN 

v_CLOB:='<?xml version="1.0" encoding="UTF-8"?>
<TransactionDetail xmlns="http://www.exchangenetwork.net/schema/tts/1" 
   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">';

   select XMLForest(
              TRANS_ID as "TransactionId",
              op.OPERATION_NAME as "DataflowName",
              ws.WEB_SERVICE_NAME as "TransactionType",
              (select STATUS_CD from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "TransactionStatus",
              (select substr(MESSAGE,1,100) from NODE_OPERATION_LOG_STATUS 
                  where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID 
                  and OPERATION_LOG_STATUS_ID = 
                     (select max(OPERATION_LOG_STATUS_ID) from NODE_OPERATION_LOG_STATUS where OPERATION_LOG_ID = LOG.OPERATION_LOG_ID)) as "StatusDescription",
              to_char(LOG.CREATED_DTTM,'YYYY-MM-DD') || 'T' || TO_CHAR(LOG.CREATED_DTTM,'HH24:MI:SS') as "CreationDateTime",
              USER_NAME as "UserId",
                     (SELECT XMLAgg(XMLElement("Activity",
                                    XMLForest('StatusUpdate' AS "ActivityName",
                                              STATUS_CD AS "ActivityStatus",
                                              substr(MESSAGE,1,50) AS "Message",
                                              TO_CHAR(CREATED_DTTM,'YYYY-MM-DD') || 'T' || TO_CHAR(CREATED_DTTM,'HH24:MI:SS') AS "Timestamp"))
                                    )
                       FROM NODE_OPERATION_LOG_STATUS sts
                       WHERE sts.OPERATION_LOG_ID = LOG.OPERATION_LOG_ID) as "ActivityList",
                     (SELECT XMLAgg(XMLElement("Document",
                                    XMLForest(FILE_ID AS "DocumentId",
                                              FILE_NAME AS "DocumentName",
                                              FILE_NAME AS "FileName",
                                              FILE_TYPE AS "DocumentType"))
                                    )
                       FROM NODE_FILE_CABIN doc
                       WHERE doc.TRANS_ID = LOG.TRANS_ID) as "DocumentList")
    INTO v_XML
    from NODE_OPERATION_LOG LOG , NODE_OPERATION op, NODE_WEB_SERVICE ws
    where op.OPERATION_ID = LOG.OPERATION_ID
    and op.WEB_SERVICE_ID = ws.WEB_SERVICE_ID
    and LOG.TRANS_ID = p_TRANS_ID
    order by LOG.CREATED_DTTM desc;

if v_XML is not null then
   v_CLOBtemp := v_XML.getClobVal(); 
else 
   v_CLOBtemp := '';
end if;

p_RESULT:=v_CLOB || v_CLOBtemp || '</TransactionDetail>';

END USP_GENERATE_TRANSACT_DTL_XML;
/